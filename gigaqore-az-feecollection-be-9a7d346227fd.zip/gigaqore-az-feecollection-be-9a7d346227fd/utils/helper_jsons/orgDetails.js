module.exports.orgDetails = {
  "orgName": "ABC University",
  "logo": "",
  "address": {
    "address": "Bangalore",
    "district": "Bangalore",
    "state": "Karnataka",
    "country": "India",
    "pincode": "560011"
  },
  "email": "abc@gmail.com",
  "phoneNumber1": "437928753342",
  "phoneNumber2": "743298574375"
}
