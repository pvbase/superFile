exports.cronConfig = {
    "flag": true,
    "orgId": "5fa8daece3eb1f18d4250e98",
    'orgName': 'vkgi'
}

