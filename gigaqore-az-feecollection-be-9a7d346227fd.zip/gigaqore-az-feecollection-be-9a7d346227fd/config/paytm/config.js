// var PaytmConfig = {
//   mid: "Kkatvd34334425459416",
//   key: "fgkmv_RHsi6R@QXm",
//   website: "WEBSTAGING",
// };
// module.exports.PaytmConfig = PaytmConfig;


var PaytmConfig = {
    mid: "SRMEdu67211118712993",
    key: "FPRsRIO1Fsm5cnfv",
    website: "WEBSTAGING",
  };
  module.exports.PaytmConfig = PaytmConfig;

  // var PaytmConfig = {
  //   mid: "Kissht24199412842169",
  //   key: "va7HeIbl&ERSn&B2",
  //   website: "WEBSTAGING",
  // };
  // module.exports.PaytmConfig = PaytmConfig;
  
