./counts.sh
node deleteTxnsAndLedgers.js
./counts.sh
