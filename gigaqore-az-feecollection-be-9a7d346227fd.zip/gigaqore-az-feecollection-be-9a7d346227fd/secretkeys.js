const app_id = "jrvspqzx07zw573b1cerflpx";
const app_secret = "12gf9q7zwjrvspqzx";

module.exports = {
  ken42: {
    jwtSecret: "zenprivatekey",
    jwtTokenexpiresTime: "24h",
  },
  zq: {
    jwtSecret: "zenprivatekey",
    jwtTokenexpiresTime: "24h",
  },
};
