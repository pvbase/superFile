#!/bin/bash

mkdir /home/ubuntu/zq-edu-ui
cd /home/ubuntu/zq-edu-ui
sudo npm install