const Recaptcha = {
    // key:"6LdePMUUAAAAADw8xZ2uhUy6lW-Cabd3nioBbBt-" //old-recaptcha sitekey
    secret:'6Lcu3ckZAAAAAKTKmR5AYmYZzBkypxvx1BBc88Uo', //Zenqore Account Recapcha Secret Key
    key: '6Lcu3ckZAAAAAPojHmrRh_c0NlFzRFEhmHyt3XIk' //zen-recaptcha sitekey
}

export default { Recaptcha }
