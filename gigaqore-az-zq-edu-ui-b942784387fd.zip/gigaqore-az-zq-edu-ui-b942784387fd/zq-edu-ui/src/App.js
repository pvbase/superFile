import React from 'react';
import './app.scss';
import LoginComponent from './components/login/login';
function App() {
  return (
    <div className="App">
      <LoginComponent />

    </div>
  );
}

export default App;
